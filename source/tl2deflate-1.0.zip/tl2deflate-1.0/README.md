# tl2deflate — faster PAK decompression for Torchlight 2

Torchlight 2 decompresses everything it reads from its PAK files with a copy of zlib 1.2.3 built into
`Torchlight2.exe`, on the main thread. In the hitch logs that decompression was 12–17% of in-play hitch
time and most of the 70–110 ms hitches around autosaves. tl2deflate sends those calls to
[libdeflate](https://github.com/ebiggers/libdeflate) instead, which decodes the same data about twice as
fast and returns byte-for-byte identical output.

It does not modify any game file. It is a `version.dll` placed in the game folder; Windows loads it before
any game code runs.

## What it does at startup

1. Forwards every `version.dll` function to the real one in Windows, so the game sees no difference.
2. Checks that the host is `Torchlight2.exe` with PE timestamp `0x5735e56a` (the GOG build it was
   tested on; other builds are untested and will simply not be patched if their bytes differ), then compares the original
   bytes of zlib's `uncompress()` (rva `0x406ca0`, 175 bytes) and of both places that call it
   (rva `0x2778d9` and `0x28d3d1`), applying the relocation offset so ASLR doesn't matter. If anything
   differs (another game version, another mod that touched these spots) it **patches nothing**.
3. Redirects those two `call` instructions to its own `uncompress()`. Nothing else in the exe changes, and
   the original zlib routine stays intact.
4. If `tl2hitchlog.dll` is present (the hitch logger, renamed), loads it, so both can run together.

The replacement decodes with libdeflate. On success it returns `Z_OK` and the output size, exactly as
zlib would. On *any* other result it calls the game's original zlib routine, so damaged or unusual data
behaves exactly as before, error codes included.

## Install

In the game folder (the one with `Torchlight2.exe`):

1. If you want to keep the hitch logger: rename the existing `version.dll` to `tl2hitchlog.dll`.
2. Copy the new `version.dll` in.
3. **First session, verify mode:** create an empty file named `tl2deflate.verify`. Play for 20–30 minutes
   with a few zone changes, then quit. In this mode the game always gets zlib's result; libdeflate runs
   alongside on the same data and every result is compared and timed.
4. Open `tl2deflate.log`. The last line should read `MISMATCH=0`, and it reports the measured speedup,
   for example `verify: match=8412 both_failed=0 MISMATCH=0 zlib=1830ms libdeflate=840ms speedup=2.1x`.
   (Verify mode is slower than normal, since it decompresses everything twice.)
5. Delete `tl2deflate.verify`. From then on it runs in fast mode. Each session's log line shows
   `fast_ok` (calls served by libdeflate) and `fallback` (calls handed to zlib; expect 0).

## Turn it off

- Temporarily: create an empty file `tl2deflate.disable` (the logger still loads).
- Remove: delete `version.dll`, and rename `tl2hitchlog.dll` back to `version.dll` if you use the logger.

## The log

`tl2deflate.log` in the game folder. One line per launch saying whether it patched and why or why not,
the first few fallbacks or mismatches if any occur, and a summary every 5 minutes and at exit.

## Exactness

libdeflate is stricter-or-equal to zlib on almost everything, but stock libdeflate deliberately accepts a
few malformed constructs that zlib 1.2.3 rejects (invalid length symbols 286/287 and distance symbols 30/31,
more than 286/30 symbols in a dynamic header, and some incomplete Huffman codes). A real compressor never
produces these, but if libdeflate succeeded where zlib fails, the fallback could not catch it. So the
bundled libdeflate 1.24 carries a small patch (`patches/libdeflate-1.24-zlib123-strict.patch`) that rejects
exactly what zlib 1.2.3 rejects. With it, for every input, either both decoders fail (and the game gets
zlib's own error) or both succeed with identical output.

Testing done before release:

- **Against the game's own code:** the test harness maps your `Torchlight2.exe` under Wine, applies its
  relocations, and calls its real `uncompress()` machine code side by side with the replacement on 79,313
  streams: valid data in many zlib configurations and capacities, 60,000 randomly damaged streams, and 42
  hand-built edge cases. Result: identical return code, length and bytes on every one.
- **Edge cases:** the 42 hand-built streams each target one of the leniencies above. Stock libdeflate
  accepted 27 that zlib 1.2.3 rejects; the patched build matches zlib on all 42.
- **Fuzzing:** 800,000 randomly generated and damaged streams (every zlib level, strategy and window
  size) against zlib 1.2.3 built from source: no differences.
- **Speed:** on game-like data (UTF-16 text, mesh and texture-style buffers) the replacement ran about
  2.1–2.2× faster than the game's zlib. That was measured under Wine; verify mode measures it on your PC.
- **Installer:** refuses a damaged image, patches both sites, refuses to patch twice, does nothing in a
  non-Torchlight host, honours `tl2deflate.disable`, and forwards `version.dll` calls correctly.

Multiplayer: decompressed data is byte-identical, so nothing the game computes from it can change.

## Building

Requires 32-bit MinGW-w64 (`i686-w64-mingw32-gcc`). `./build.sh` produces `out/version.dll`.
`tools/gen_expected.py` regenerates `src/expected.h` from an exe. `test/` holds the corpus generators,
the Wine differential test (`difftest.c`) and the native fuzzer.

## Licences

tl2deflate: MIT. libdeflate: MIT (Eric Biggers), `third_party/libdeflate/COPYING`. zlib 1.2.3 (used only by
the tests): zlib licence.
