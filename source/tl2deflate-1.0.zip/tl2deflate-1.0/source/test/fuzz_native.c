/* Mutation fuzzer: random data -> zlib 1.2.3 deflate (random level/strategy/window/memlevel) -> random
 * damage -> compare zlib 1.2.3 uncompress() against libdeflate+fallback. Also mutates edge.bin records. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "zlib.h"
#include "libdeflate.h"
static unsigned long long s = 88172645463325252ull;
static unsigned rnd(void) { s ^= s << 13; s ^= s >> 7; s ^= s << 17; return (unsigned)(s >> 11); }
static unsigned char src[1 << 20], comp[1 << 21], A[1 << 21], B[1 << 21];
static unsigned char *seeds[64]; static unsigned seedlen[64], seedcap[64], nseeds;
int main(int argc, char **argv) {
    unsigned long iters = strtoul(argv[1], 0, 10), mism = 0, ok = 0, i;
    struct libdeflate_decompressor *d = libdeflate_alloc_decompressor();
    if (argc > 2) { FILE *f = fopen(argv[2], "rb"); unsigned h[3];
        while (nseeds < 64 && fread(h, 4, 3, f) == 3) { seeds[nseeds] = malloc(h[0]); fread(seeds[nseeds], 1, h[0], f); seedlen[nseeds] = h[0]; seedcap[nseeds++] = h[1]; } }
    if (argc > 3) s ^= strtoull(argv[3], 0, 10) * 0x9E3779B97F4A7C15ull;
    for (i = 0; i < iters; i++) {
        unsigned n, cl, cap, k, j; uLongf la; size_t lb; int ra, rb; enum libdeflate_result r;
        if (nseeds && rnd() % 4 == 0) { k = rnd() % nseeds; memcpy(comp, seeds[k], seedlen[k]); cl = seedlen[k]; n = seedcap[k]; }
        else {
            unsigned mode = rnd() % 5; z_stream z; memset(&z, 0, sizeof z);
            n = (rnd() % 8 == 0) ? rnd() % 300000 : rnd() % 3000;
            for (j = 0; j < n; j++) src[j] = mode == 0 ? rnd() : mode == 1 ? "ab"[rnd() & 1] : mode == 2 ? (j % 37) : mode == 3 ? 0 : (rnd() % 16 ? src[j ? j - 1 : 0] : rnd());
            deflateInit2(&z, (int)(rnd() % 10), Z_DEFLATED, 9 + (int)(rnd() % 7), 1 + (int)(rnd() % 9), (int)(rnd() % 5 == 4 ? Z_DEFAULT_STRATEGY : rnd() % 4));
            z.next_in = src; z.avail_in = n; z.next_out = comp; z.avail_out = sizeof comp;
            deflate(&z, Z_FINISH); cl = (unsigned)z.total_out; deflateEnd(&z);
        }
        /* damage */
        switch (rnd() % 6) {
        case 0: break;                                                     /* valid */
        case 1: case 2: for (j = 1 + rnd() % 3; j--; ) if (cl) comp[rnd() % cl] ^= 1 << (rnd() % 8); break;
        case 3: if (cl) cl = rnd() % cl; break;
        case 4: if (cl > 6) { unsigned p = 2 + rnd() % (cl - 6); comp[p] = rnd(); } break;
        case 5: if (cl > 2) { unsigned p = rnd() % (cl > 40 ? 40 : cl); comp[p] ^= 1 << (rnd() % 8); } break; /* near block headers */
        }
        switch (rnd() % 4) { case 0: case 1: cap = n; break; case 2: cap = n + rnd() % 1000; break; default: cap = n ? rnd() % (n + 1) : 0; }
        la = cap; ra = uncompress(A, &la, comp, cl);
        r = libdeflate_zlib_decompress(d, comp, cl, B, cap, &lb);
        if (r == LIBDEFLATE_SUCCESS) rb = 0; else { rb = ra; lb = la; }
        if (ra != rb || (ra == 0 && (la != lb || memcmp(A, B, la)))) {
            if (++mism <= 5) { char fn[64]; FILE *o; unsigned h[3] = {cl, cap, 0};
                printf("MISMATCH iter %lu cl=%u cap=%u zlib=%d/%lu lib=%d/%zu\n", i, cl, cap, ra, la, (int)r, lb);
                sprintf(fn, "testrun/fuzzfail_%lu.bin", mism); o = fopen(fn, "wb"); fwrite(h, 4, 3, o); fwrite(comp, 1, cl, o); fclose(o); }
        } else if (ra == 0) ok++;
    }
    printf("iters=%lu valid_both=%lu MISMATCH=%lu\n", iters, ok, mism);
    return mism != 0;
}
