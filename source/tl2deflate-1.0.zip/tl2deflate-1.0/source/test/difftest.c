/* Differential test: Torchlight2.exe's own uncompress() (stock zlib 1.2.3 machine code, run in place)
 * versus tl2deflate's tl2_uncompress(), on a corpus of valid and damaged zlib streams.
 * Also exercises the call-site installer on the mapped exe image.
 * usage: difftest.exe Torchlight2.exe version.dll corpus.bin [verify]                       */
#include <windows.h>
#include <stdio.h>
#include <string.h>

typedef int (__cdecl *uncompress_fn)(unsigned char *, unsigned long *, const unsigned char *, unsigned long);
typedef int (__cdecl *install_fn)(HMODULE, int);

/* Wine maps the exe without applying base relocations when DONT_RESOLVE_DLL_REFERENCES is used;
 * Windows applies them. Apply them here so the mapped image matches what the game sees. */
static void apply_relocs(unsigned char *base)
{
    IMAGE_NT_HEADERS32 *nt = (IMAGE_NT_HEADERS32 *)(base + ((IMAGE_DOS_HEADER *)base)->e_lfanew);
    IMAGE_DATA_DIRECTORY dd = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
    DWORD delta = (DWORD)base - nt->OptionalHeader.ImageBase, off = 0, applied = 0, probe;
    memcpy(&probe, base + 0x406cc5, 4);
    if (probe != 0x021a6458u) { printf("loader already relocated the image\n"); return; }
    while (off < dd.Size) {
        IMAGE_BASE_RELOCATION *blk = (IMAGE_BASE_RELOCATION *)(base + dd.VirtualAddress + off);
        WORD *e = (WORD *)(blk + 1);
        DWORD k, cnt = (blk->SizeOfBlock - sizeof(*blk)) / 2;
        if (!blk->SizeOfBlock) break;
        for (k = 0; k < cnt; k++) if ((e[k] >> 12) == IMAGE_REL_BASED_HIGHLOW) {
            DWORD *p = (DWORD *)(base + blk->VirtualAddress + (e[k] & 0xfff)), old;
            VirtualProtect(p, 4, PAGE_EXECUTE_READWRITE, &old);
            *p += delta; applied++;
            VirtualProtect(p, 4, old, &old);
        }
        off += blk->SizeOfBlock;
    }
    printf("applied %lu relocations (delta %08lx)\n", applied, delta);
}

static void resolve_imports(unsigned char *base)
{
    IMAGE_NT_HEADERS32 *nt = (IMAGE_NT_HEADERS32 *)(base + ((IMAGE_DOS_HEADER *)base)->e_lfanew);
    IMAGE_DATA_DIRECTORY dd = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    IMAGE_IMPORT_DESCRIPTOR *d = (IMAGE_IMPORT_DESCRIPTOR *)(base + dd.VirtualAddress);
    int resolved = 0;
    for (; d->Name; d++) {
        const char *dll = (const char *)(base + d->Name);
        HMODULE h;
        IMAGE_THUNK_DATA32 *names, *iat;
        if (_stricmp(dll, "MSVCR90.dll") && _stricmp(dll, "KERNEL32.dll")) continue;
        h = LoadLibraryA(dll);
        if (!h) { printf("cannot load %s\n", dll); continue; }
        names = (IMAGE_THUNK_DATA32 *)(base + (d->OriginalFirstThunk ? d->OriginalFirstThunk : d->FirstThunk));
        iat = (IMAGE_THUNK_DATA32 *)(base + d->FirstThunk);
        for (; names->u1.AddressOfData; names++, iat++) {
            FARPROC f;
            DWORD old;
            if (names->u1.Ordinal & IMAGE_ORDINAL_FLAG32) continue;
            f = GetProcAddress(h, (const char *)((IMAGE_IMPORT_BY_NAME *)(base + names->u1.AddressOfData))->Name);
            if (!f) continue;
            VirtualProtect(&iat->u1.Function, 4, PAGE_READWRITE, &old);
            iat->u1.Function = (DWORD)f;
            VirtualProtect(&iat->u1.Function, 4, old, &old);
            resolved++;
        }
    }
    printf("resolved %d MSVCR90/KERNEL32 imports in the mapped exe\n", resolved);
}

int main(int argc, char **argv)
{
    HMODULE exe, dll;
    uncompress_fn orig, mine;
    install_fn install;
    FILE *f;
    unsigned char *A, *B, *src;
    unsigned long tail_diff = 0, n = 0, both_ok = 0, both_fail = 0, mismatch = 0, timed = 0;
    unsigned long long tin = 0, tout = 0;
    LARGE_INTEGER q, t0, t1, ta = {0}, tb = {0};
    int mode, r, i;
    unsigned char *base;
    const unsigned long BUF = 4u << 20;

    if (argc < 4) { printf("usage\n"); return 2; }
    mode = (argc > 4 && !strcmp(argv[4], "verify")) ? 2 : 1;
    exe = LoadLibraryExA(argv[1], NULL, DONT_RESOLVE_DLL_REFERENCES);
    if (!exe) { printf("cannot map exe (%lu)\n", GetLastError()); return 2; }
    base = (unsigned char *)exe;
    printf("exe mapped at %p (preferred 00400000)\n", exe);
    apply_relocs(base);
    resolve_imports(base);
    orig = (uncompress_fn)(base + 0x406ca0);

    dll = LoadLibraryA(argv[2]);
    if (!dll) { printf("cannot load dll (%lu)\n", GetLastError()); return 2; }
    install = (install_fn)GetProcAddress(dll, "tl2d_install");
    mine = (uncompress_fn)GetProcAddress(dll, "tl2_uncompress");

    /* Installer must refuse a damaged image: flip a byte inside uncompress(), expect refusal, restore. */
    {
        DWORD old; unsigned char save = base[0x406ca0 + 40];
        VirtualProtect(base + 0x406ca0, 64, PAGE_EXECUTE_READWRITE, &old);
        base[0x406ca0 + 40] ^= 0xff;
        r = install(exe, mode);
        printf("install on damaged image -> %d (expect 4)\n", r);
        base[0x406ca0 + 40] = save;
        VirtualProtect(base + 0x406ca0, 64, old, &old);
        if (r != 4) return 1;
    }
    r = install(exe, mode);
    printf("install(mode=%d) -> %d\n", mode, r);
    if (r) return 1;
    for (i = 0; i < 2; i++) {
        unsigned char *site = base + (i ? 0x28d3d1 : 0x2778d9);
        long rel; memcpy(&rel, site + 1, 4);
        printf("site %s: %02x -> %p (tl2_uncompress=%p) %s\n", i ? "0x28d3d1" : "0x2778d9", site[0],
               site + 5 + rel, (void *)mine, (site[0] == 0xE8 && site + 5 + rel == (unsigned char *)mine) ? "OK" : "WRONG");
        if (!(site[0] == 0xE8 && site + 5 + rel == (unsigned char *)mine)) return 1;
    }
    r = install(exe, mode);
    printf("second install -> %d (expect refusal: site bytes now differ)\n", r);
    if (r == 0) return 1;

    A = VirtualAlloc(NULL, BUF, MEM_COMMIT, PAGE_READWRITE);
    B = VirtualAlloc(NULL, BUF, MEM_COMMIT, PAGE_READWRITE);
    src = VirtualAlloc(NULL, BUF, MEM_COMMIT, PAGE_READWRITE);
    f = fopen(argv[3], "rb");
    if (!f) return 2;
    QueryPerformanceFrequency(&q);
    for (;;) {
        unsigned long hdr[3], la, lb;
        int ra, rb;
        if (fread(hdr, 4, 3, f) != 3) break;
        if (hdr[0] > BUF || hdr[1] > BUF - 64) { printf("record too large\n"); return 2; }
        if (fread(src, 1, hdr[0], f) != hdr[0]) break;
        n++;
        memset(A, 0xA5, hdr[1] + 64); memset(B, 0xA5, hdr[1] + 64);
        la = lb = hdr[1];
        QueryPerformanceCounter(&t0);
        ra = orig(A, &la, src, hdr[0]);
        QueryPerformanceCounter(&t1);
        if (hdr[2] & 1) ta.QuadPart += t1.QuadPart - t0.QuadPart;
        QueryPerformanceCounter(&t0);
        rb = mine(B, &lb, src, hdr[0]);
        QueryPerformanceCounter(&t1);
        if (hdr[2] & 1) { tb.QuadPart += t1.QuadPart - t0.QuadPart; timed++; tin += hdr[0]; if (ra == 0) tout += la; }
        /* Same return code, same length; on success same bytes and nothing written past the length. */
        if (ra == 0 && ra == rb && la == lb && memcmp(A + la, B + lb, hdr[1] - la + 64)) tail_diff++;
        if (ra != rb || la != lb || (ra == 0 && memcmp(A, B, la))) {
            if (++mismatch <= 20)
                printf("MISMATCH rec %lu: srcLen=%lu cap=%lu zlib ret=%d len=%lu | tl2 ret=%d len=%lu\n",
                       n, hdr[0], hdr[1], ra, la, rb, lb);
        } else if (ra == 0) both_ok++;
        else both_fail++;
    }
    fclose(f);
    printf("records=%lu identical_success=%lu identical_failure=%lu MISMATCHES=%lu\n", n, both_ok, both_fail, mismatch);
    printf("successes where bytes after the output end (spare capacity) differ: %lu\n", tail_diff);
    printf("timing on %lu valid streams (%llu KB in, %llu KB out): exe zlib %.1f ms, tl2_uncompress %.1f ms, ratio %.2fx\n",
           timed, tin >> 10, tout >> 10, ta.QuadPart * 1000.0 / q.QuadPart, tb.QuadPart * 1000.0 / q.QuadPart,
           tb.QuadPart ? (double)ta.QuadPart / tb.QuadPart : 0.0);
    return mismatch ? 1 : 0;
}
