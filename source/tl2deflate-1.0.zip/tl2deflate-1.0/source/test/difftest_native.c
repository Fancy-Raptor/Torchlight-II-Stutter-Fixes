/* Native (Linux) quick check: stock zlib 1.2.3 uncompress() vs libdeflate_zlib_decompress() + fallback. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "zlib.h"
#include "libdeflate.h"
int main(int argc, char **argv) {
    FILE *f = fopen(argv[1], "rb"); unsigned h[3]; unsigned long n = 0, ok = 0, fail = 0, mism = 0, lib_only = 0;
    struct libdeflate_decompressor *d = libdeflate_alloc_decompressor();
    unsigned char *src = malloc(8 << 20), *A = malloc(8 << 20), *B = malloc(8 << 20);
    while (fread(h, 4, 3, f) == 3) {
        uLongf la = h[1]; size_t lb = 0; int ra, rb; enum libdeflate_result r;
        if (fread(src, 1, h[0], f) != h[0]) break; n++;
        ra = uncompress(A, &la, src, h[0]);
        r = libdeflate_zlib_decompress(d, src, h[0], B, h[1], &lb);
        if (r == LIBDEFLATE_SUCCESS) { rb = 0; } else { rb = ra; lb = la; }   /* fallback == zlib */
        if (r == LIBDEFLATE_SUCCESS && ra != 0) lib_only++;
        if (ra != rb || (ra == 0 && (la != lb || memcmp(A, B, la)))) {
            if (++mism <= 10) printf("MISMATCH rec %lu srcLen=%u cap=%u zlib=%d/%lu lib=%d/%zu\n", n, h[0], h[1], ra, la, (int)r, lb);
        } else if (ra == 0) ok++; else fail++;
    }
    printf("records=%lu same_ok=%lu same_fail=%lu MISMATCH=%lu (libdeflate-accepts-zlib-rejects=%lu)\n", n, ok, fail, mism, lib_only);
    return mism != 0;
}
