"""Builds a differential-test corpus of zlib streams: valid ones in many configurations, plus mutated,
truncated, padded and header-tweaked ones. Record format (little endian):
    u32 srcLen, u32 destCap, u32 flags, srcLen bytes
flags bit0 = 'timing' (valid stream, used for speed comparison)."""
import os, random, struct, sys, zlib

rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 12345)
out = open(sys.argv[1], 'wb')
count = [0]

def rec(src, cap, flags=0):
    out.write(struct.pack('<III', len(src), cap, flags)); out.write(src); count[0] += 1

def text_utf16(n):
    words = ['[UNIT]', '<STRING>NAME:', '<INTEGER>LEVEL:', '<FLOAT>SCALE:', 'media/models/', '[/UNIT]',
             '<BOOL>DONTCREATE:', 'true', 'false', 'SKELETON', '.MESH', 'SOUNDS', 'EFFECT', '\r\n', '\t']
    s = ''.join(rng.choice(words) + (str(rng.randint(0, 9999)) if rng.random() < .3 else '') for _ in range(n // 8 + 1))
    return s.encode('utf-16-le')[:n]

def payload(n):
    k = rng.randrange(7)
    if k == 0: return os.urandom(n)
    if k == 1: return bytes(n)
    if k == 2: return text_utf16(n)
    if k == 3: return bytes(rng.choice(b'ab') for _ in range(n))
    if k == 4:  # structured binary (vertex-like floats)
        return b''.join(struct.pack('<f', rng.choice([0.0, 1.0, -1.0, rng.uniform(-50, 50)])) for _ in range(n // 4 + 1))[:n]
    if k == 5:  # long repeats with variation -> long matches, max distances
        base = os.urandom(rng.randint(1, 40000)); b = bytearray()
        while len(b) < n: b += base[: rng.randint(1, len(base))]; b += os.urandom(rng.randint(0, 50))
        return bytes(b[:n])
    return bytes((i * 7 + (i >> 8)) & 0xff for i in range(n))

def compress(data, level, wbits, mem, strat, zdict=None):
    c = zlib.compressobj(level, zlib.DEFLATED, wbits, mem, strat, **({'zdict': zdict} if zdict else {}))
    return c.compress(data) + c.flush()

def sizes(n_small, n_big):
    for _ in range(n_small): yield rng.choice([0, 1, 2, 3, 7, 64, 255, 256, 1000, rng.randint(0, 20000)])
    for _ in range(n_big): yield rng.choice([65536, 131072, rng.randint(20000, 2_000_000)])

strategies = [zlib.Z_DEFAULT_STRATEGY, zlib.Z_FILTERED, zlib.Z_HUFFMAN_ONLY, zlib.Z_RLE, zlib.Z_FIXED]
valid = []
for n in sizes(int(sys.argv[3]) if len(sys.argv) > 3 else 3000, int(sys.argv[4]) if len(sys.argv) > 4 else 300):
    data = payload(n)
    level = rng.choice([-1, 0, 1, 2, 6, 9, rng.randint(0, 9)])
    wbits = rng.choice([15, 15, 15, rng.randint(9, 15)])
    s = compress(data, level, wbits, rng.randint(1, 9), rng.choice(strategies))
    valid.append((data, s))
    rec(s, len(data), 1)                                # exact capacity (what the PAK reader does)
    rec(s, len(data) + rng.randint(1, 4096))            # spare capacity
    if len(data) > 0:
        rec(s, len(data) - 1)                           # one byte short
        rec(s, rng.randint(0, len(data) - 1))           # far too short
    rec(s + os.urandom(rng.randint(1, 64)), len(data))  # trailing junk
    rec(s, 0)                                           # zero capacity

small = [v for v in valid if len(v[1]) < 20000]
# Mutations of valid streams: bit flips, byte replacements, truncation, adler/header corruption.
for _ in range(int(sys.argv[5]) if len(sys.argv) > 5 else 60000):
    data, s = rng.choice(small)
    b = bytearray(s); k = rng.randrange(8)
    if k <= 2 and len(b) > 2:
        for _ in range(rng.choice([1, 1, 1, 2, 3, 8])):
            i = rng.randrange(len(b)); b[i] ^= 1 << rng.randrange(8)
    elif k == 3 and len(b) > 2:
        i = rng.randrange(len(b)); b[i] = rng.randrange(256)
    elif k == 4:
        b = b[: rng.randrange(len(b) + 1)]
    elif k == 5 and len(b) >= 6:
        b[-1 - rng.randrange(4)] ^= 1 << rng.randrange(8)       # adler32
    elif k == 6 and len(b) >= 2:
        b[rng.randrange(2)] ^= 1 << rng.randrange(8)            # header
    else:
        i = rng.randrange(len(b) + 1); b[i:i] = os.urandom(rng.randint(1, 4))
    cap = rng.choice([len(data), len(data), len(data) + 100, max(0, len(data) - 1), 1 << 16])
    rec(bytes(b), cap)

# Hand-made edge cases.
for data in [b'', b'x', b'hello world' * 100]:
    d = b'some preset dictionary bytes'
    rec(compress(data, 6, 15, 8, 0, zdict=d), len(data) + 10)       # FDICT set -> zlib Z_DATA_ERROR
    s = compress(data, 6, 15, 8, 0)
    for cinfo in range(16):                                           # every CINFO, FCHECK fixed up
        cmf = (cinfo << 4) | 8; flg = s[1] & 0xe0
        flg |= (31 - ((cmf << 8) | flg) % 31) % 31
        rec(bytes([cmf, flg]) + s[2:], len(data) + 10)
    rec(s[:2], 10); rec(s[:5], 10); rec(b'', 10); rec(b'\x78', 10)
    rec(bytes([s[0], s[1]]) + zlib.compress(data, 6)[2:-4] + b'\0\0\0\0', len(data))   # zero adler
    raw = zlib.compressobj(6, zlib.DEFLATED, -15); r = raw.compress(data) + raw.flush()
    rec(r, len(data) + 10)                                            # raw deflate, no zlib header
out.close()
print(count[0], 'records')
