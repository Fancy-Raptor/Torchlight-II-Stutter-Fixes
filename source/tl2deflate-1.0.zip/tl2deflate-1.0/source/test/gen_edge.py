"""Hand-built DEFLATE streams for the places where stock libdeflate is more lenient than zlib 1.2.3.
Each case is written so that *unpatched* libdeflate would accept it (adler32 computed on the output a
lenient decoder produces), so a passing test really shows the patch closes the gap.
Output: same record format as gen_corpus.py."""
import random, struct, sys, zlib

rng = random.Random(7)
out = open(sys.argv[1], 'wb'); n = [0]

class BW:
    def __init__(s): s.b = bytearray(); s.acc = 0; s.k = 0
    def bits(s, v, k):                      # LSB-first (extra bits, header fields)
        s.acc |= v << s.k; s.k += k
        while s.k >= 8: s.b.append(s.acc & 255); s.acc >>= 8; s.k -= 8
    def code(s, c, k):                      # Huffman code, MSB-first
        s.bits(int(format(c, f'0{k}b')[::-1], 2) if k else 0, k)
    def done(s):
        if s.k: s.b.append(s.acc & 255)
        return bytes(s.b)

def canon(lens):
    mx = max(lens) if lens else 0; cnt = [0] * (mx + 2)
    for l in lens:
        if l: cnt[l] += 1
    code = 0; nxt = [0] * (mx + 2)
    for b in range(1, mx + 1): code = (code + cnt[b - 1]) << 1; nxt[b] = code
    codes = {}
    for sym, l in enumerate(lens):
        if l: codes[sym] = (nxt[l], l); nxt[l] += 1
    return codes

FIX_LIT = [8] * 144 + [9] * 112 + [7] * 24 + [8] * 8
FIX_DIST = [5] * 32
LBASE = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,258,258]
LEXTRA = [0]*8 + [1]*4 + [2]*4 + [3]*4 + [4]*4 + [5]*4 + [0,0,0]
DBASE = [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,24577,24577]
DEXTRA = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,13,13]

def emit(bw, lit, dist, items, outbuf, lenient=True, codeword_override=None):
    """items: ('L', byte) | ('M', lensym, lextra, distsym, dextra) | ('E',). Tracks lenient output."""
    for it in items:
        if it[0] == 'L':
            c, k = lit[it[1]]; bw.code(c, k); outbuf.append(it[1])
        elif it[0] == 'E':
            c, k = lit[256]; bw.code(c, k)
        elif it[0] == 'RAW':                 # write an arbitrary codeword (e.g. the unused '1')
            bw.code(it[1], it[2])
        else:
            _, ls, le, ds, de = it
            c, k = lit[ls]; bw.code(c, k); bw.bits(le, LEXTRA[ls - 257])
            c, k = dist[ds]; bw.code(c, k); bw.bits(de, DEXTRA[ds])
            L = LBASE[ls - 257] + le; D = DBASE[ds] + de
            for _ in range(L): outbuf.append(outbuf[-D] if D <= len(outbuf) else 0)

def wrap(raw, outdata):
    return b'\x78\x9c' + raw + struct.pack('>I', zlib.adler32(bytes(outdata)) & 0xffffffff)

def rec(stream, cap, label):
    out.write(struct.pack('<III', len(stream), cap, 0)); out.write(stream); n[0] += 1

def static_stream(items):
    bw = BW(); bw.bits(1, 1); bw.bits(1, 2); o = bytearray()
    emit(bw, canon(FIX_LIT), canon(FIX_DIST), items + [('E',)], o)
    return wrap(bw.done(), o), o

def lit_run(k, seed=0):
    r = random.Random(seed); return [('L', r.randrange(256)) for _ in range(k)]

# 1-2: static block, litlen 285 (valid twin) / 286 / 287
for ls in (285, 286, 287):
    for pre in (1, 5, 300):
        s, o = static_stream(lit_run(pre, ls) + [('M', ls, 0, 0, 0)] + lit_run(3))
        rec(s, len(o), f'static len{ls}'); rec(s, len(o) + 500, '')

# 3: static block, dist 29 (valid twin) / 30 / 31 with output large enough that lenient decoders accept
for ds in (29, 30, 31):
    for de in (0, 1, 8191):
        pre = 40000
        s, o = static_stream(lit_run(pre, ds) + [('M', 270, 1, ds, de)] + lit_run(10))
        rec(s, len(o), f'static dist{ds}')

def dyn_stream(litlens, distlens, items, prelens=None, cl_syms=None, hlit=None, hdist=None, final=True):
    nlit = hlit or len(litlens); ndist = hdist or len(distlens)
    allens = list(litlens) + [0] * (nlit - len(litlens)) + list(distlens) + [0] * (ndist - len(distlens))
    order = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]
    if prelens is None:
        used = sorted(set(allens)); prelens = [0] * 19
        k = max(1, (len(used) - 1).bit_length())
        # complete code over the used lengths: give all used symbols length k, pad with others if needed
        syms = used + [s for s in range(19) if s not in used]
        for s in syms[: 1 << k]: prelens[s] = k
    pc = canon(prelens)
    bw = BW(); bw.bits(1 if final else 0, 1); bw.bits(2, 2)
    hclen = 19
    while hclen > 4 and prelens[order[hclen - 1]] == 0: hclen -= 1
    bw.bits(nlit - 257, 5); bw.bits(ndist - 1, 5); bw.bits(hclen - 4, 4)
    for i in range(hclen): bw.bits(prelens[order[i]], 3)
    for l in (cl_syms if cl_syms is not None else allens):
        if isinstance(l, tuple): bw.code(l[0], l[1])
        else: c, k = pc[l]; bw.code(c, k)
    o = bytearray()
    lit = canon(allens[:nlit]); dist = canon(allens[nlit:])
    emit(bw, lit, dist, items, o)
    return wrap(bw.done(), o), o

def full_litlens(n=286):                 # complete litlen code: 256 symbols len 8 + rest len 9 ... keep simple
    lens = [0] * n
    syms = list(range(0, 256)) + [256] + list(range(257, min(n, 286)))
    # Kraft-complete assignment: 2^9 = 512 slots; give 'a' symbols len 8 and the rest len 9
    k8 = 512 - len(syms)                 # each len-8 symbol uses 2 slots
    for i, s in enumerate(syms): lens[s] = 8 if i < k8 else 9
    return lens

body = lit_run(50, 1) + [('M', 260, 0, 0, 0), ('M', 270, 1, 3, 0)] + lit_run(5, 2) + [('E',)]
dl = [4] * 16                            # complete distance code, 16 symbols of length 4
# 4: valid dynamic block (twin)
s, o = dyn_stream(full_litlens(), dl, body); rec(s, len(o), 'dyn valid')
# 5: HLIT = 287/288 and HDIST = 31/32 with the extra lengths zero -> zlib "too many length or distance symbols"
for hl, hd in ((287, 16), (288, 16), (286, 31), (286, 32), (288, 32)):
    s, o = dyn_stream(full_litlens(), dl, body, hlit=hl, hdist=hd); rec(s, len(o), f'dyn hlit{hl} hdist{hd}')
# 6: single length-1 distance codeword; use codeword '0' (valid) and '1' (zlib: invalid distance code)
lit = full_litlens()
for use_one in (False, True):
    items = lit_run(20, 3) + [('M', 260, 0, 0, 0)] + [('E',)]
    s, o = dyn_stream(lit, [1], items)
    if use_one:   # rewrite: same stream but the distance codeword is '1' -> lenient decoders still use dist sym 0
        bw_items = lit_run(20, 3)
        # build manually: emit match length then RAW '1' for distance
        nlit = 286; allens = lit + [1]
        order = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]
        used = sorted(set(allens)); prelens = [0] * 19; k = max(1, (len(used) - 1).bit_length())
        for sx in (used + [x for x in range(19) if x not in used])[: 1 << k]: prelens[sx] = k
        pc = canon(prelens); bw = BW(); bw.bits(1, 1); bw.bits(2, 2)
        hclen = 19
        while hclen > 4 and prelens[order[hclen - 1]] == 0: hclen -= 1
        bw.bits(0, 5 - 0) if False else None
        bw.bits(nlit - 257, 5); bw.bits(0, 5); bw.bits(hclen - 4, 4)
        for i in range(hclen): bw.bits(prelens[order[i]], 3)
        for l in allens: c, kk = pc[l]; bw.code(c, kk)
        L = canon(lit); o = bytearray()
        emit(bw, L, {}, bw_items, o)
        c, kk = L[260]; bw.code(c, kk); bw.code(1, 1)              # length 6, distance codeword '1'
        for _ in range(6): o.append(o[-1])
        c, kk = L[256]; bw.code(c, kk)
        s = wrap(bw.done(), o)
    rec(s, len(o), f'single dist codeword use_one={use_one}')
# 7: empty distance code (HDIST=1, length 0) with a match -> zlib invalid distance code; lenient: offset 1
s, o = dyn_stream(full_litlens(), [0], lit_run(10, 4) + [('E',)]); rec(s, len(o), 'empty dist, no match (valid)')
nlit = 286; lit = full_litlens(); allens = lit + [0]
used = sorted(set(allens)); prelens = [0] * 19; k = max(1, (len(used) - 1).bit_length())
for sx in (used + [x for x in range(19) if x not in used])[: 1 << k]: prelens[sx] = k
order = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]
pc = canon(prelens); bw = BW(); bw.bits(1, 1); bw.bits(2, 2); hclen = 19
while hclen > 4 and prelens[order[hclen - 1]] == 0: hclen -= 1
bw.bits(nlit - 257, 5); bw.bits(0, 5); bw.bits(hclen - 4, 4)
for i in range(hclen): bw.bits(prelens[order[i]], 3)
for l in allens: c, kk = pc[l]; bw.code(c, kk)
L = canon(lit); o = bytearray(); emit(bw, L, {}, lit_run(10, 5), o)
for cw in (0, 1):
    b2 = BW(); b2.b = bytearray(bw.b); b2.acc = bw.acc; b2.k = bw.k; o2 = bytearray(o)
    c, kk = L[257]; b2.code(c, kk); b2.code(cw, 1)                 # length 3, 'distance' bit
    for _ in range(3): o2.append(o2[-1])
    c, kk = L[256]; b2.code(c, kk)
    rec(wrap(b2.done(), o2), len(o2), f'empty dist + match bit {cw}')
# 8: litlen code with a single length-1 codeword (EOB): codeword '0' valid, '1' invalid
for cw in (0, 1):
    lens = [0] * 257; lens[256] = 1
    allens = lens + [0]
    prelens = [0] * 19; prelens[0] = 1; prelens[1] = 1
    pc = canon(prelens); bw = BW(); bw.bits(1, 1); bw.bits(2, 2)
    hclen = 19
    while hclen > 4 and prelens[order[hclen - 1]] == 0: hclen -= 1
    bw.bits(0, 5); bw.bits(0, 5); bw.bits(hclen - 4, 4)
    for i in range(hclen): bw.bits(prelens[order[i]], 3)
    for l in allens: c, kk = pc[l]; bw.code(c, kk)
    bw.code(cw, 1)
    rec(wrap(bw.done(), b''), 10, f'single litlen codeword bit {cw}')
# 9: incomplete precode (one precode symbol of length 1) -> zlib 1.2.3 rejects; empty precode -> both fail
for pre in ('single', 'empty'):
    prelens = [0] * 19
    if pre == 'single': prelens[8] = 1
    pc = canon(prelens); bw = BW(); bw.bits(1, 1); bw.bits(2, 2); hclen = 19
    bw.bits(0, 5); bw.bits(0, 5); bw.bits(hclen - 4, 4)
    for i in range(hclen): bw.bits(prelens[order[i]], 3)
    for _ in range(258):
        if pre == 'single': bw.code(0, 1)
        else: bw.bits(0, 1)
    rec(wrap(bw.done(), b''), 10, f'precode {pre}')
out.close(); print(n[0], 'edge records')
