#!/bin/sh
# Builds version.dll (tl2deflate) with the 32-bit MinGW-w64 toolchain.
set -e
cd "$(dirname "$0")"
LD=third_party/libdeflate
CC=${CC:-i686-w64-mingw32-gcc}
CFLAGS="-O2 -mstackrealign -fno-strict-aliasing -Wall -Wno-unused-function -I$LD -Isrc"
mkdir -p out
$CC $CFLAGS -shared -o out/version.dll \
    src/tl2deflate.c src/version.def \
    $LD/lib/deflate_decompress.c $LD/lib/zlib_decompress.c $LD/lib/adler32.c \
    $LD/lib/utils.c $LD/lib/x86/cpu_features.c \
    -static-libgcc -Wl,--dynamicbase,--nxcompat,--kill-at -s
echo built out/version.dll
