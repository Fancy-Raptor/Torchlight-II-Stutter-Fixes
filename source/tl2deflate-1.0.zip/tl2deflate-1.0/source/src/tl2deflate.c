/*
 * tl2deflate - faster PAK decompression for Torchlight 2 (GOG build, exe timestamp 0x5735e56a)
 *
 * Installs as version.dll in the game folder. On load it:
 *   1. forwards all version.dll exports to the real system version.dll,
 *   2. checks the original bytes of zlib's uncompress() and its two call sites in Torchlight2.exe
 *      (relocation-aware, so it works with ASLR); if anything differs it patches nothing,
 *   3. redirects those two calls to tl2_uncompress(), which decodes with libdeflate and falls back
 *      to the game's own zlib routine on any non-success result,
 *   4. loads tl2hitchlog.dll (the hitch logger, renamed) if it is present.
 *
 * Control files next to Torchlight2.exe:
 *   tl2deflate.disable  - do not patch (proxy + logger chain-load only)
 *   tl2deflate.verify   - verify mode: the game always gets zlib's result; libdeflate runs on the side
 *                         and every result is compared and timed. Use this for a session or two first.
 * Log: tl2deflate.log next to the exe.
 *
 * libdeflate is MIT licensed (Eric Biggers). This file is released under the MIT license too.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string.h>
#include "libdeflate.h"
#include "expected.h"

#define TL2D_VERSION "1.0"

/* ------------------------------------------------------------------ version.dll proxy */

#define VERSION_EXPORTS(X) \
    X(GetFileVersionInfoA, 16) X(GetFileVersionInfoByHandle, 16) X(GetFileVersionInfoExA, 20) \
    X(GetFileVersionInfoExW, 20) X(GetFileVersionInfoSizeA, 8) X(GetFileVersionInfoSizeExA, 12) \
    X(GetFileVersionInfoSizeExW, 12) X(GetFileVersionInfoSizeW, 8) X(GetFileVersionInfoW, 16) \
    X(VerFindFileA, 32) X(VerFindFileW, 32) X(VerInstallFileA, 32) X(VerInstallFileW, 32) \
    X(VerLanguageNameA, 12) X(VerLanguageNameW, 12) X(VerQueryValueA, 16) X(VerQueryValueW, 16)

/* Fallbacks used only if the real DLL lacks an export: fail cleanly with the right stack cleanup. */
#define FAIL_STUB(name, argbytes) \
    __attribute__((naked)) static void fail_##name(void) { \
        __asm__ volatile("xorl %%eax, %%eax\n\tret $" #argbytes ::: "memory"); }
VERSION_EXPORTS(FAIL_STUB)

#define REAL_PTR(name, argbytes) void *real_##name = (void *)fail_##name;
VERSION_EXPORTS(REAL_PTR)

/* Exported stubs: jump straight to the real function, so arguments and return pass through untouched. */
#define JMP_STUB(name, argbytes) \
    __attribute__((naked)) void proxy_##name(void) { __asm__ volatile("jmp *%0" :: "m"(real_##name)); }
VERSION_EXPORTS(JMP_STUB)

static HMODULE g_real_version;

static void load_real_version(void)
{
    WCHAR path[MAX_PATH + 32];
    UINT n = GetSystemDirectoryW(path, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return;
    lstrcpyW(path + n, L"\\version.dll");
    g_real_version = LoadLibraryW(path);
    if (!g_real_version) return;
#define RESOLVE(name, argbytes) { FARPROC f = GetProcAddress(g_real_version, #name); if (f) real_##name = (void *)f; }
    VERSION_EXPORTS(RESOLVE)
}

/* ------------------------------------------------------------------ logging */

static WCHAR g_dir[MAX_PATH];          /* game folder, with trailing backslash */
static CRITICAL_SECTION g_log_cs;

static void log_write(const char *s)
{
    WCHAR path[MAX_PATH + 32];
    HANDLE h;
    DWORD w;
    lstrcpyW(path, g_dir);
    lstrcatW(path, L"tl2deflate.log");
    EnterCriticalSection(&g_log_cs);
    h = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h != INVALID_HANDLE_VALUE) {
        WriteFile(h, s, (DWORD)strlen(s), &w, NULL);
        CloseHandle(h);
    }
    LeaveCriticalSection(&g_log_cs);
}

static void logf_(const char *fmt, ...)
{
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    wvsprintfA(buf, fmt, ap);   /* user32; the game imports it anyway */
    va_end(ap);
    log_write(buf);
}

static int file_exists(const WCHAR *name)
{
    WCHAR path[MAX_PATH + 64];
    lstrcpyW(path, g_dir);
    lstrcatW(path, name);
    return GetFileAttributesW(path) != INVALID_FILE_ATTRIBUTES;
}

/* ------------------------------------------------------------------ the replacement */

typedef int (__cdecl *uncompress_fn)(unsigned char *, unsigned long *, const unsigned char *, unsigned long);

enum { MODE_OFF = 0, MODE_FAST = 1, MODE_VERIFY = 2 };
static volatile LONG g_mode = MODE_OFF;
static uncompress_fn g_orig;
static DWORD g_tls = TLS_OUT_OF_INDEXES;

struct tls_state {
    struct libdeflate_decompressor *d;
    unsigned char *scratch;
    size_t scratch_cap;
};

/* Statistics. uncompress() is only called from the main thread in practice, but stay safe. */
static CRITICAL_SECTION g_stat_cs;
static struct {
    unsigned long long calls, fast_ok, fallback, bytes_in, bytes_out;
    unsigned long long fallback_by_result[4];
    unsigned long long qpc_total, qpc_orig, qpc_lib;    /* verify mode times both */
    unsigned long long verify_ok, verify_mismatch, verify_both_fail;
    DWORD last_summary_tick;
} g_st;
static LARGE_INTEGER g_qpf;

static struct tls_state *get_tls(void)
{
    struct tls_state *t;
    if (g_tls == TLS_OUT_OF_INDEXES) return NULL;
    t = (struct tls_state *)TlsGetValue(g_tls);
    if (!t) {
        t = (struct tls_state *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(*t));
        if (!t) return NULL;
        t->d = libdeflate_alloc_decompressor();
        TlsSetValue(g_tls, t);
    }
    return t;
}

static void free_tls(void)
{
    struct tls_state *t;
    if (g_tls == TLS_OUT_OF_INDEXES) return;
    t = (struct tls_state *)TlsGetValue(g_tls);
    if (!t) return;
    if (t->d) libdeflate_free_decompressor(t->d);
    if (t->scratch) HeapFree(GetProcessHeap(), 0, t->scratch);
    HeapFree(GetProcessHeap(), 0, t);
    TlsSetValue(g_tls, NULL);
}

static unsigned long ms_of(unsigned long long q)
{
    return g_qpf.QuadPart ? (unsigned long)(q * 1000ull / (unsigned long long)g_qpf.QuadPart) : 0;
}

static void write_summary(const char *why)
{
    char buf[1024];
    EnterCriticalSection(&g_stat_cs);
    wsprintfA(buf,
        "[summary:%s] mode=%s calls=%lu fast_ok=%lu fallback=%lu (bad_data=%lu short_output=%lu "
        "insufficient_space=%lu other=%lu) in=%luKB out=%luKB time_in_uncompress=%lums",
        why, g_mode == MODE_VERIFY ? "verify" : g_mode == MODE_FAST ? "fast" : "off",
        (unsigned long)g_st.calls, (unsigned long)g_st.fast_ok, (unsigned long)g_st.fallback,
        (unsigned long)g_st.fallback_by_result[1], (unsigned long)g_st.fallback_by_result[2],
        (unsigned long)g_st.fallback_by_result[3], (unsigned long)g_st.fallback_by_result[0],
        (unsigned long)(g_st.bytes_in >> 10), (unsigned long)(g_st.bytes_out >> 10), ms_of(g_st.qpc_total));
    if (g_mode == MODE_VERIFY) {
        unsigned long o = ms_of(g_st.qpc_orig), l = ms_of(g_st.qpc_lib);
        unsigned long x10 = l ? (unsigned long)((g_st.qpc_orig * 10ull) / (g_st.qpc_lib ? g_st.qpc_lib : 1)) : 0;
        wsprintfA(buf + lstrlenA(buf),
            " | verify: match=%lu both_failed=%lu MISMATCH=%lu zlib=%lums libdeflate=%lums speedup=%lu.%lux",
            (unsigned long)g_st.verify_ok, (unsigned long)g_st.verify_both_fail,
            (unsigned long)g_st.verify_mismatch, o, l, x10 / 10, x10 % 10);
    }
    lstrcatA(buf, "\r\n");
    LeaveCriticalSection(&g_stat_cs);
    log_write(buf);
}

static int result_index(enum libdeflate_result r)
{
    switch (r) {
    case LIBDEFLATE_BAD_DATA: return 1;
    case LIBDEFLATE_SHORT_OUTPUT: return 2;
    case LIBDEFLATE_INSUFFICIENT_SPACE: return 3;
    default: return 0;
    }
}

/* Run libdeflate exactly the way the fast path does. Returns 1 on success. */
static int lib_decode(struct tls_state *t, unsigned char *dest, unsigned long cap,
                      const unsigned char *src, unsigned long srcLen, size_t *out_len, enum libdeflate_result *res)
{
    *res = LIBDEFLATE_BAD_DATA;
    *out_len = 0;
    /* zlib returns Z_STREAM_ERROR for NULL buffers; leave those to zlib. */
    if (!t || !t->d || !dest || !src) return 0;
    *res = libdeflate_zlib_decompress(t->d, src, srcLen, dest, cap, out_len);
    return *res == LIBDEFLATE_SUCCESS;
}

static void verify_one(struct tls_state *t, int zret, unsigned long cap, unsigned long zlen,
                       const unsigned char *zout, const unsigned char *src, unsigned long srcLen)
{
    size_t out_len;
    enum libdeflate_result r;
    LARGE_INTEGER a, b;
    int ok;
    if (!t) return;
    if (t->scratch_cap < cap || !t->scratch) {
        size_t want = cap ? cap : 1;
        if (t->scratch) HeapFree(GetProcessHeap(), 0, t->scratch);
        t->scratch = (unsigned char *)HeapAlloc(GetProcessHeap(), 0, want);
        t->scratch_cap = t->scratch ? want : 0;
        if (!t->scratch) return;
    }
    QueryPerformanceCounter(&a);
    ok = lib_decode(t, t->scratch, cap, src, srcLen, &out_len, &r);
    QueryPerformanceCounter(&b);
    EnterCriticalSection(&g_stat_cs);
    g_st.qpc_lib += (unsigned long long)(b.QuadPart - a.QuadPart);
    if (zret == 0 && ok && out_len == zlen && memcmp(t->scratch, zout, zlen) == 0) g_st.verify_ok++;
    else if (zret != 0 && !ok) g_st.verify_both_fail++;
    else {
        unsigned long long n = ++g_st.verify_mismatch;
        LeaveCriticalSection(&g_stat_cs);
        if (n <= 50)
            logf_("MISMATCH #%lu: zlib ret=%d len=%lu | libdeflate result=%d len=%lu | srcLen=%lu cap=%lu\r\n",
                  (unsigned long)n, zret, zlen, (int)r, (unsigned long)out_len, srcLen, cap);
        return;
    }
    LeaveCriticalSection(&g_stat_cs);
}

/* Same signature and calling convention as zlib 1.2.3 uncompress() in the exe. */
__declspec(dllexport) int __cdecl tl2_uncompress(unsigned char *dest, unsigned long *destLen,
                                                 const unsigned char *src, unsigned long srcLen)
{
    LARGE_INTEGER t0, t1;
    struct tls_state *t;
    int ret;
    unsigned long cap;
    DWORD now;

    if (!destLen) return g_orig(dest, destLen, src, srcLen);
    QueryPerformanceCounter(&t0);
    cap = *destLen;
    t = get_tls();

    if (g_mode == MODE_VERIFY) {
        LARGE_INTEGER a;
        ret = g_orig(dest, destLen, src, srcLen);         /* the game gets zlib's result, always */
        QueryPerformanceCounter(&a);
        EnterCriticalSection(&g_stat_cs);
        g_st.qpc_orig += (unsigned long long)(a.QuadPart - t0.QuadPart);
        LeaveCriticalSection(&g_stat_cs);
        verify_one(t, ret, cap, *destLen, dest, src, srcLen);
    } else {
        size_t out_len;
        enum libdeflate_result r;
        if (lib_decode(t, dest, cap, src, srcLen, &out_len, &r)) {
            *destLen = (unsigned long)out_len;
            ret = 0;                                      /* Z_OK */
            EnterCriticalSection(&g_stat_cs);
            g_st.fast_ok++;
            LeaveCriticalSection(&g_stat_cs);
        } else {
            unsigned long long n;
            ret = g_orig(dest, destLen, src, srcLen);     /* original behavior, original error codes */
            EnterCriticalSection(&g_stat_cs);
            n = ++g_st.fallback;
            g_st.fallback_by_result[result_index(r)]++;
            LeaveCriticalSection(&g_stat_cs);
            if (n <= 20)
                logf_("fallback #%lu: libdeflate result=%d -> zlib ret=%d len=%lu (srcLen=%lu cap=%lu)\r\n",
                      (unsigned long)n, (int)r, ret, *destLen, srcLen, cap);
        }
    }

    QueryPerformanceCounter(&t1);
    EnterCriticalSection(&g_stat_cs);
    g_st.calls++;
    g_st.bytes_in += srcLen;
    if (ret == 0) g_st.bytes_out += *destLen;
    g_st.qpc_total += (unsigned long long)(t1.QuadPart - t0.QuadPart);
    now = GetTickCount();
    if (now - g_st.last_summary_tick >= 300000) {        /* every 5 minutes, in case the game crashes */
        g_st.last_summary_tick = now;
        LeaveCriticalSection(&g_stat_cs);
        write_summary("periodic");
    } else {
        LeaveCriticalSection(&g_stat_cs);
    }
    return ret;
}

/* ------------------------------------------------------------------ patching */

static int check_blob(const unsigned char *at, const unsigned char *expect, unsigned n,
                      const unsigned short *relocs, unsigned long delta)
{
    unsigned char buf[256];
    unsigned i;
    if (n > sizeof(buf)) return 0;
    if (IsBadReadPtr(at, n)) return 0;
    memcpy(buf, expect, n);
    for (i = 0; relocs[i] != 0xffff; i++) {
        unsigned long v;
        memcpy(&v, buf + relocs[i], 4);
        v += delta;
        memcpy(buf + relocs[i], &v, 4);
    }
    return memcmp(at, buf, n) == 0;
}

static int write_call(unsigned char *site, void *target)
{
    DWORD old;
    LONG rel = (LONG)((unsigned char *)target - (site + 5));
    if (site[0] != 0xE8) return 0;
    if (!VirtualProtect(site, 5, PAGE_EXECUTE_READWRITE, &old)) return 0;
    memcpy(site + 1, &rel, 4);
    VirtualProtect(site, 5, old, &old);
    FlushInstructionCache(GetCurrentProcess(), site, 5);
    return 1;
}

/* Returns 0 on success, or a reason code. Exported so the test harness can run it on a mapped exe. */
__declspec(dllexport) int __cdecl tl2d_install(HMODULE exe, int mode)
{
    unsigned char *base = (unsigned char *)exe;
    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)base;
    IMAGE_NT_HEADERS32 *nt;
    unsigned long delta;

    if (mode != MODE_FAST && mode != MODE_VERIFY) return 1;
    if (!base || dos->e_magic != IMAGE_DOS_SIGNATURE) return 2;
    nt = (IMAGE_NT_HEADERS32 *)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->FileHeader.TimeDateStamp != TL2_TIMESTAMP) return 3;
    delta = (unsigned long)base - TL2_PREFERRED_BASE;

    if (!check_blob(base + RVA_UNCOMPRESS, exp_uncompress, sizeof(exp_uncompress), exp_uncompress_relocs, delta))
        return 4;
    if (!check_blob(base + RVA_SITE_A - 19, exp_site_a, sizeof(exp_site_a), exp_site_a_relocs, delta)) return 5;
    if (!check_blob(base + RVA_SITE_B - 15, exp_site_b, sizeof(exp_site_b), exp_site_b_relocs, delta)) return 6;

    g_orig = (uncompress_fn)(base + RVA_UNCOMPRESS);
    g_mode = mode;
    if (!write_call(base + RVA_SITE_A, (void *)tl2_uncompress)) { g_mode = MODE_OFF; return 7; }
    if (!write_call(base + RVA_SITE_B, (void *)tl2_uncompress)) {
        write_call(base + RVA_SITE_A, (void *)g_orig);    /* undo, leave the exe as it was */
        g_mode = MODE_OFF;
        return 8;
    }
    return 0;
}

static const char *reason_text(int r)
{
    switch (r) {
    case 0: return "patched both uncompress() call sites";
    case 3: return "not the expected Torchlight2.exe (PE timestamp differs) - nothing patched";
    case 4: return "uncompress() bytes differ from the expected build - nothing patched";
    case 5: return "call site 0x2778d9 bytes differ - nothing patched";
    case 6: return "call site 0x28d3d1 bytes differ - nothing patched";
    case 7: case 8: return "VirtualProtect failed - nothing patched";
    default: return "unexpected error - nothing patched";
    }
}

/* ------------------------------------------------------------------ entry point */

static HMODULE g_logger;

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID reserved)
{
    (void)inst;
    if (reason == DLL_PROCESS_ATTACH) {
        WCHAR *slash;
        HMODULE exe = GetModuleHandleW(NULL);
        IMAGE_NT_HEADERS32 *nt = (IMAGE_NT_HEADERS32 *)((unsigned char *)exe + ((IMAGE_DOS_HEADER *)exe)->e_lfanew);

        InitializeCriticalSection(&g_log_cs);
        InitializeCriticalSection(&g_stat_cs);
        QueryPerformanceFrequency(&g_qpf);
        g_st.last_summary_tick = GetTickCount();
        g_tls = TlsAlloc();
        load_real_version();

        GetModuleFileNameW(NULL, g_dir, MAX_PATH);
        slash = g_dir;
        { WCHAR *p; for (p = g_dir; *p; p++) if (*p == L'\\' || *p == L'/') slash = p + 1; }
        *slash = 0;

        /* Only touch the host if it is Torchlight 2; otherwise be a plain version.dll proxy. */
        if (nt->FileHeader.TimeDateStamp == TL2_TIMESTAMP) {
            SYSTEMTIME st;
            int r = -1;
            int want = file_exists(L"tl2deflate.disable") ? MODE_OFF
                     : file_exists(L"tl2deflate.verify") ? MODE_VERIFY : MODE_FAST;
            GetLocalTime(&st);
            if (want != MODE_OFF) r = tl2d_install(exe, want);
            logf_("==== tl2deflate " TL2D_VERSION " (libdeflate " LIBDEFLATE_VERSION_STRING ") %04u-%02u-%02u %02u:%02u:%02u"
                  " exe base=%08lx mode=%s: %s\r\n",
                  st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, (unsigned long)exe,
                  want == MODE_VERIFY ? "verify" : want == MODE_FAST ? "fast" : "disabled",
                  want == MODE_OFF ? "tl2deflate.disable present - nothing patched" : reason_text(r));

            /* Chain-load the hitch logger if the user renamed it. */
            {
                WCHAR path[MAX_PATH + 32];
                lstrcpyW(path, g_dir);
                lstrcatW(path, L"tl2hitchlog.dll");
                if (GetFileAttributesW(path) != INVALID_FILE_ATTRIBUTES) {
                    g_logger = LoadLibraryW(path);
                    logf_("logger tl2hitchlog.dll: %s\r\n", g_logger ? "loaded" : "FAILED to load");
                }
            }
        }
    } else if (reason == DLL_THREAD_DETACH) {
        free_tls();
    } else if (reason == DLL_PROCESS_DETACH) {
        if (g_mode != MODE_OFF) write_summary("exit");
        (void)reserved;
    }
    return TRUE;
}
